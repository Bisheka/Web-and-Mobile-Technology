let library = [];

function addBook(title, author, year) { 
    let newBook = { 
        id: library.length + 1, 
        title: title, 
        author: author, 
        year: year, 
        isAvailable: true 
    }; 
    library.push(newBook); 
    console.log(`✓ Added: "${title}" by ${author}`); 
} 

console.log("--- Task 4 Output ---");
addBook("1984", "George Orwell", 1949);
addBook("The Great Gatsby", "F. Scott Fitzgerald", 1925);
console.log("Current Library Size:", library.length);