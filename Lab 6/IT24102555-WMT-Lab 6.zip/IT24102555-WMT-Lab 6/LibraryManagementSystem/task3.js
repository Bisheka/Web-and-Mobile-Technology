let library = [  
{ id: 1, title: "Harry Potter", author: "J.K. Rowling", year: 1997, isAvailable: true }, 
{ id: 2, title: "The Hobbit", author: "J.R.R. Tolkien", year: 1937, isAvailable: true },]; 
 
function displayAllBooks() { 
    console.log("\n=== Library Books ==="); 
    for (let i = 0; i < library.length; i++) { 
        let book = library[i]; 
        let status = book.isAvailable ? "Available" : "Borrowed"; 
        console.log(`${book.id}. "${book.title}" by ${book.author} (${book.year}) - 
${status}`); 
    } 
} 
displayAllBooks(); 