let library = [ 
    { id: 1, title: "Harry Potter", isAvailable: true }, 
    { id: 2, title: "The Hobbit", isAvailable: true } 
]; 

function borrowBook(bookId) { 
    const book = library.find(b => b.id === bookId); 
    if (!book || !book.isAvailable) {
        console.log(`Error: Book ${bookId} is not available.`);
        return;
    } 
    book.isAvailable = false; 
    console.log(`Success: You borrowed "${book.title}"`);
} 

function returnBook(bookId) { 
    const book = library.find(b => b.id === bookId); 
    if (!book || book.isAvailable) return; 
    book.isAvailable = true; 
    console.log(`Success: You returned "${book.title}"`);
}

console.log("--- Task 6 Output ---");
borrowBook(1);
console.log("Status of Book 1:", library[0].isAvailable ? "Available" : "Borrowed");
returnBook(1);
console.log("Status of Book 1:", library[0].isAvailable ? "Available" : "Borrowed");