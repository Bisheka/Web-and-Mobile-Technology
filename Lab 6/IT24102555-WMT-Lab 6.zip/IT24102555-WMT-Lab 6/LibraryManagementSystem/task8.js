let library = [ 
    { id: 1, title: "Harry Potter" }, 
    { id: 2, title: "The Hobbit" } 
]; 

function deleteBook(bookId) { 
    const index = library.findIndex(b => b.id === bookId); 
    if (index === -1) {
        console.log("Error: Book not found.");
        return;
    } 
    console.log(`Deleting: ${library[index].title}`);
    library.splice(index, 1); 
} 

console.log("--- Task 8 Output ---");
console.log("Before delete, count:", library.length);
deleteBook(1);
console.log("After delete, count:", library.length);