// Create a single book 
let book = { 
id: 1, 
title: " Harry Potter ", 
author: " J.K. Rowling ", 
year:1997, 
isAvailable: true 
}; 
console.log("Book Title:", book.title); 
console.log("Author:", book.author); 
console.log("Available:", book.isAvailable); 