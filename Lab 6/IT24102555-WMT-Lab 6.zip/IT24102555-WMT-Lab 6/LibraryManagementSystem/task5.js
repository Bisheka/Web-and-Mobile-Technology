let library = [
    { id: 1, title: "Harry Potter", author: "J.K. Rowling", isAvailable: true },
    { id: 2, title: "The Hobbit", author: "J.R.R. Tolkien", isAvailable: true }
];

function searchBook(title) { 
    let found = null; 
    for (let i = 0; i < library.length; i++) { 
        if (library[i].title.toLowerCase() === title.toLowerCase()) { 
            found = library[i]; 
            break; 
        } 
    } 

    if (found) { 
        console.log(`Found: ${found.title} - ${found.isAvailable ? "Available" : "Borrowed"}`); 
    } else { 
        console.log("Book not found"); 
    } 
}

console.log("--- Task 5 Output ---");
searchBook("harry potter");
searchBook("Moby Dick");