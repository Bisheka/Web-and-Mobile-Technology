let library = [ 
    { 
        id: 1, 
        title: "Harry Potter", 
        author: "J.K. Rowling", 
        year: 1997, 
        isAvailable: true 
    }, 
    { 
        id: 2, 
        title: "The Hobbit", 
        author: "J.R.R. Tolkien", 
        year: 1937, 
        isAvailable: true 
    }, 
]; 
console.log("Total books:", library.length); 
console.log("\nFirst book:", library[0].title); 
console.log("Second book:", library[1].title); 