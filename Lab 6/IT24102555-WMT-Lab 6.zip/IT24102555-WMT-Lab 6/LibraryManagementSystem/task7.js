let library = [ 
    { title: "Harry Potter", isAvailable: true }, 
    { title: "The Hobbit", isAvailable: false },
    { title: "1984", isAvailable: true }
]; 

function showAvailableBooks() { 
    console.log("Available Books:");
    library.filter(b => b.isAvailable).forEach(b => console.log(` - ${b.title}`)); 
} 

function showBorrowedBooks() { 
    console.log("Borrowed Books:");
    library.filter(b => !b.isAvailable).forEach(b => console.log(` - ${b.title}`)); 
} 

console.log("--- Task 7 Output ---");
showAvailableBooks();
showBorrowedBooks();
