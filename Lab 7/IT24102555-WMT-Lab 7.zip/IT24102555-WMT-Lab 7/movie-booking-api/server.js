//import express framework
const exprees = require('express');

//create express application
const app = exprees();

//Enable Json request body parsing
app.use(exprees.json());    

//design server port
const port = 3000;

//start the server
app.listen(port,()=>{
    console.log(`Server is running on http://localhost:${port}`);
});

//in memory array to store booking data
let bookings = [];

//API-1: Create a new booking
app.post('/bookings',(req,res)=>{
    const { bookingId, movieName, customerName,ticketCount } = req.body;
    const newBooking = {
         bookingId, 
         movieName, 
         customerName,
         ticketCount 
        };

bookings.push(newBooking);

res.json({
    message : "Booking added successfully",
    booking : newBooking
});

});

// API-2: View All Bookings (GET)
app.get('/bookings', (req, res) => {
    res.json(bookings);
});

// API-3: View Bookings By ID (GET)
app.get('/bookings/:id', (req, res) => {
    const Id = parseInt(req.params.id);

    const booking = bookings.find(b => b.bookingId === Id);

    if (!booking) {
        return res.status(404).json({ 
            message: "Booking not found" 
        });
    }
    res.json(booking);
});

//API-4: Update a Booking (PUT)
app.put('/bookings/:id', (req, res) => {

    const Id = parseInt(req.params.id);

    const booking = bookings.find(b => b.bookingId === Id);

    if (!booking) {
        return res.status(404).json({ 
            message: "Booking not found" 
        });
    }

   const { movieName, customerName, ticketCount } = req.body;

   if (movieName) booking.movieName = movieName;
   if (customerName) booking.customerName = customerName;
   if (ticketCount) booking.ticketCount = ticketCount;

    res.json({
        message: "Booking updated successfully",
        booking: booking
    });
});

//API-5:Delete Booking(DELETE)
app.delete('/bookings/:id', (req, res) => {

        const Id = parseInt(req.params.id);

        const index = bookings.findIndex(b => b.bookingId === Id);

        if (index === -1) {
            return res.status(404).json({
                message: "Booking not found"
            });
        }

        bookings.splice(index, 1);

        res.json({
            message:"Booking delete successfully"
        });
    });