
const minAge = 18;


let students = [];


function submitForm() {

 
    let name = document.getElementById("name").value;
    let age = Number(document.getElementById("age").value);
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;

  
    switch (true) {

        case (name === "" || email === ""):
            alert("Validation failed: Empty fields");
            return false;

        case (age < minAge):
            alert("Validation failed: Age below 18");
            return false;

        case (phone.length !== 10 || isNaN(phone)):
            alert("Validation failed: Phone number must be at least 10 digits");
            return false;

        default:
            alert("Validation successful");
    }

    // Create student object
    let student = {
        name: name,
        age: age,
        email: email,
        phone: phone
    };


    students.push(student);

    console.clear();
    for (let i = 0; i < students.length; i++) {
        console.log(
            "Name: " + students[i].name +
            ", Age: " + students[i].age +
            ", Email: " + students[i].email +
            ", Phone: " + students[i].phone
        );
    }

    // Clear form fields
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("email").value = "";
    document.getElementById("phone").value = "";

   
    document.getElementById("name").focus();

    return false;
}