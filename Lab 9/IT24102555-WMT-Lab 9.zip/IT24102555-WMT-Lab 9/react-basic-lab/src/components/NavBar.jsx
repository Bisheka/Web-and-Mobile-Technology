function Navbar({ cartCount }) {
    return (
      <nav className="navbar">
        <h2>Pet Shop</h2>
        <ul className="nav-links">
          <li>Home</li>
          <li>Pet</li>
          <li>Contact</li>
          <li>Cart ({cartCount})</li>
        </ul>
      </nav>
    );
  }
  
  export default Navbar;