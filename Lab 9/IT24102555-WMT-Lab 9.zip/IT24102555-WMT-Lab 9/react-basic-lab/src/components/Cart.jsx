function Cart({ cartCount }) {
    return (
      <div className="cart">
        <h2>Shopping Cart</h2>
        <p>Total Items in Cart: {cartCount}</p>
      </div>
    );
  }
  
  export default Cart;