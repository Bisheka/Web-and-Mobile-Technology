function Pet({ name, type, price, stock, onAddToCart }) {
    return (
      <div className="pet-card">
        <h3>{name}</h3>
        <p>Type: {type}</p>
        <p>Price: Rs. {price}</p>
        <p>Stock: {stock}</p>
        <div>
          <button onClick={onAddToCart} disabled={stock === 0}>
            {stock > 0 ? "Add to cart" : "Out of stock"}
          </button>
        </div>
      </div>
    );
  }
  
  export default Pet;